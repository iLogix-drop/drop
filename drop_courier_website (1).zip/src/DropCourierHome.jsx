
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function DropCourierHome() {
  return (
    <div className="bg-yellow-400 min-h-screen text-blue-900 p-6">
      <header className="text-center">
        <img src="/logo.png" alt="Drop Logo" className="mx-auto w-32" />
        <h1 className="text-3xl font-bold mt-4">Local and Provincial Couriers</h1>
        <p className="mt-2 font-semibold">We do drops differently. No stress, no searching—you're the drop location. We find you.</p>
      </header>

      <section className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Parcel Tracking</h2>
            <p>Track your parcel in real-time using your tracking number.</p>
            <Button className="mt-4 w-full">Track Parcel</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Motorbike Delivery</h2>
            <ul className="list-disc list-inside">
              <li>Fast for small parcels</li>
              <li>Lower delivery cost</li>
              <li>Priority delivery options</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Packaging & Labeling</h2>
            <p>Pre-order packaging or buy at drop points. Labels include all client info and special instructions.</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Smart Lockers</h2>
            <ul className="list-disc list-inside">
              <li>QR Code access</li>
              <li>Biometric unlocking via phone</li>
              <li>2FA with SMS/Email</li>
              <li>Emergency RFID/NFC unlock</li>
              <li>Battery backup</li>
            </ul>
            <p className="mt-2 font-semibold">Security is our priority. Your parcels are safe with our cutting-edge locker tech.</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Locker Sizes</h2>
            <ul className="list-inside">
              <li>Small: 400 x 400 x 400 mm (64,000 cm³)</li>
              <li>Medium: 600 x 400 x 400 mm (96,000 cm³)</li>
              <li>Large: 800 x 400 x 600 mm (192,000 cm³)</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <h2 className="text-xl font-semibold mb-2">Contact Us</h2>
            <p>WhatsApp Helpline: 068 307 6692</p>
            <div className="flex gap-4 mt-2">
              <a href="https://facebook.com" target="_blank">Facebook</a>
              <a href="https://instagram.com" target="_blank">Instagram</a>
            </div>
          </CardContent>
        </Card>
      </section>

      <footer className="mt-10 text-center text-sm">
        <p>© {new Date().getFullYear()} drop.co.za. All rights reserved.</p>
      </footer>
    </div>
  );
}
